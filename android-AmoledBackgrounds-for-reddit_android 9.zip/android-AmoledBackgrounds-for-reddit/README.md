Source code of "AmoledBackgrounds for reddit"

On Play Store: https://play.google.com/store/apps/details?id=com.droidheat.amoledbackgrounds
